local _, core = ...;

core.LocalClass = {}

FillLocalizedClassList(core.LocalClass)